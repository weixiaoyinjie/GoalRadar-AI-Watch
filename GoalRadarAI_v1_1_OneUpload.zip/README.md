# GoalRadar AI 1.1 — 进球压力预警修复版

基于用户提供的 GoalRadar AI v1 源码修复。只关注图片识别的 Fixture ID + API-Football 实时比赛数据 + 连续快照压力变化 + Android 通知。不会通过赔率推算进球概率。

## 使用方法

1. 安装 GitHub Actions 打包的 `GoalRadarAI-v1.1-debug.apk`（与旧版并行）。
2. 在新版的 API 设置中保存 API-Football Key，OpenAI Key 可选。
3. 先按「测试手机通知」，若收不到，到 Android 应用通知设置打开授权及“进球压力预警”通知渠道。
4. 从其他 App 导入带 `Fixture ID: 1234567` 的比赛图像（或手动输入 ID）。新版添加成功且有足球 API Key 时会自动启动。
5. 观察屏幕「最近 API 成功」是否持续更新，比赛状态是否显示 1H / 2H，及实时射门/xG是否有效。
6. 在设置里选择“中压及以上（较敏感）”或“高压及以上（较严格）”。

**注意**：压力预警基于至少两个时点的真实API统计；可以漏掉快速突发进球，尤其是角球、反击、点球或 API 数据延迟情形。新增「进球确认」是进球后的通知，不能误认为赛前预测。

API-Football 查询为 `GET /fixtures?ids=...`，在支持的联赛中携带 `statistics` 和 `events` 数据。任何来源缺失 `xG` 都不会伪造。外部软件的 Fixture ID 必须是相同 API 供应商的 ID。轮询频率越高使用的API额度越多。

## GitHub 安装/构建

把 `GoalRadarAI_v1_1_OneUpload.zip` 上传 GitHub 仓库**根目录**，把 `build-apk.yml` 内容放在 `.github/workflows/build-apk.yml`（替换原文件全部内容），保存后从 Actions 构建。

不要把旧版 ZIP 中的工作流覆盖新版的修复工作流。新版解压步骤已经排除此路径。

版本已改为 `applicationId=com.goalradar.ai.fix`，与旧版并存，不会继承旧版本机 API Key。请勿将 API Key 提交到公开 GitHub 仓库。

## 测试

`tests/RiskEngineSmoke.java` 验证高压、无 xG 降级、无基线、低压力和进球比分变化判定逻辑；这是逻辑级测试，不能替代真实安卓通知、网络、API额度及设备省电策略验证。

## 技术限制

当前仍是前台服务轮询架构；Android 15 对 dataSync 类型有后台累计运行时长上限。没有服务器端推送，因此不能保证长时间锁屏期间的 24/7 无遗漏推送。需要长期可靠的跨设备预警，最终应迁移为云端定时采集 + FCM 推送（需要服务端和额外部署）。
