package com.goalradar.ai;

/** Difference of two authoritative API score snapshots: a confirmation, not a pre-goal forecast. */
final class GoalChangeDetector {
    static boolean newlyConfirmed(MatchSample before, MatchSample now) {
        if (before==null || now==null || !before.fixtureId.equals(now.fixtureId)) return false;
        if (!before.playing() || (!now.playing() && !"HT".equals(now.status) && !"FT".equals(now.status))) return false;
        long gap=now.capturedAt-before.capturedAt;
        if (gap<=0 || gap>15*60000L) return false;
        return now.homeGoals>before.homeGoals || now.awayGoals>before.awayGoals;
    }
}
