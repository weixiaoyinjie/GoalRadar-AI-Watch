package com.goalradar.ai;

import android.app.*;
import android.content.*;
import android.os.*;
import android.content.pm.PackageManager;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.*;

/** Foreground user-initiated monitor. Android may stop it under platform power limits. */
public final class RadarService extends Service {
    public static final String START="com.goalradar.ai.START";
    public static final String STOP="com.goalradar.ai.STOP";
    public static final String ONCE="com.goalradar.ai.ONCE";
    public static final String CHANGED="com.goalradar.ai.CHANGED";
    private static final String CHANNEL="goalradar_alerts", RUN_CHANNEL="goalradar_monitor";
    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService aiExecutor = Executors.newSingleThreadExecutor();
    private ScheduledFuture<?> task;
    private boolean working=false;
    private int nextNotificationId=100;

    @Override public void onCreate() {
        super.onCreate(); ensureChannels(this);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        String action=intent == null ? START : intent.getAction();
        if (STOP.equals(action)) {
            if(task!=null)task.cancel(false);
            Store.running(this,false); emit(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY;
        }
        startForeground(1,monitorNotification("监测启动中"));
        Store.running(this,true); emit();
        if(task==null || task.isCancelled()) {
            int seconds=Store.interval(this);
            task=executor.scheduleWithFixedDelay(this::refresh,0,seconds,TimeUnit.SECONDS);
        } else if (ONCE.equals(action)) executor.execute(this::refresh);
        return START_NOT_STICKY;
    }
    private synchronized void refresh() {
        if(working)return;
        working=true;
        Store.put(this,"heartbeat",String.valueOf(System.currentTimeMillis()));
        try {
            List<String> ids=Store.ids(this);
            if(ids.isEmpty()) { Store.put(this,"service_error","请先导入比赛"); emit(); return; }
            String key=SecurePrefs.get(this,"football");
            if(key.isEmpty()) { Store.put(this,"service_error","请先保存足球 API Key"); emit(); return; }
            Store.put(this,"service_error","");
            // API-FOOTBALL allows up to 20 fixtures per one batched request.
            List<MatchSample> matches=FootballApi.fetch(ids,key);
            Store.put(this,"api_success",String.valueOf(System.currentTimeMillis()));
            Store.put(this,"api_rows",String.valueOf(matches.size()));
            Set<String> received=new HashSet<>();
            for(MatchSample m:matches) {
                if (!ids.contains(m.fixtureId))continue;
                received.add(m.fixtureId);
                List<MatchSample> past=Store.history(this,m.fixtureId);
                MatchSample prior=past.isEmpty()?null:past.get(past.size()-1);
                RiskEngine.Result risk=RiskEngine.assess(past,m);
                // Confirmed goals are a separate notification, never a retroactive prediction.
                if (prior != null) notifyConfirmedGoal(prior,m);
                Store.append(this,m);
                Store.put(this,"risk_"+m.fixtureId,risk.json().toString());
                Store.put(this,"error_"+m.fixtureId,"");
                notifyIfNeeded(m,risk);
                aiIfNeeded(m,risk);
            }
            for(String id:ids) if(!received.contains(id)) {
                Store.put(this,"error_"+id,"API没有返回该 Fixture ID：请确认供应商一致、比赛存在且账户可访问");
            }
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .notify(1,monitorNotification("正在观察 " + ids.size() + " 场 · " + System.currentTimeMillis()));
        } catch(Exception e) {
            Store.put(this,"service_error",simplify(e));
        } finally { working=false; emit(); }
    }
    private void aiIfNeeded(MatchSample m,RiskEngine.Result risk) {
        if(risk.tier<RiskEngine.HIGH)return;
        String key=SecurePrefs.get(this,"openai");if(key.isEmpty())return;
        String lastKey="ai_timestamp_"+m.fixtureId;
        long now=System.currentTimeMillis();
        if (now-Store.longValue(this,lastKey)<10*60*1000L)return;
        Store.put(this,lastKey,String.valueOf(now));
        final String model=Store.get(this,"model").isEmpty()?"gpt-4.1-mini":Store.get(this,"model");
        aiExecutor.execute(()->{
            try {
                String summary=AiClient.explain(key,model,m,risk);
                Store.put(this,"ai_"+m.fixtureId,summary);
            } catch(Exception e) { Store.put(this,"ai_"+m.fixtureId,"AI服务错误（不影响基础预警）："+simplify(e)); }
            emit();
        });
    }
    private void notifyIfNeeded(MatchSample m,RiskEngine.Result risk) {
        if(risk.tier<Store.alertLevel(this) || !m.playing())return;
        if (!notificationsAllowed(this)) {
            Store.put(this,"service_error","通知被系统关闭：请允许 GoalRadar 的通知，再点击测试通知");
            return;
        }
        String key="alert_"+m.fixtureId;
        String value=Store.get(this,key);
        String[] parts=value.split(";",3);
        long last=0;int lastTier=0;String lastLeader="";
        if(parts.length==3) try {last=Long.parseLong(parts[0]);lastTier=Integer.parseInt(parts[1]);lastLeader=parts[2];}catch(Exception ignored) {}
        long now=System.currentTimeMillis();
        if(now-last<6*60000L && risk.tier<=lastTier)return;
        if(now-last<2*60000L)return;
        if(!lastLeader.equals(risk.leader) && now-last<3*60000L)return;
        Notification.Builder nb=new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setPriority(Notification.PRIORITY_HIGH)
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentTitle("⚽ "+(risk.tier==RiskEngine.SEVERE?"严重进球压力":risk.tier==RiskEngine.HIGH?"高压进球预警":"进球压力增加")+" · "+m.minute+"'")
                .setContentText(m.home+" "+m.homeGoals+"-"+m.awayGoals+" "+m.away)
                .setStyle(new Notification.BigTextStyle().bigText(risk.leader+" | "+risk.evidence))
                .setAutoCancel(true).setContentIntent(openAppIntent());
        try {
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(nextNotificationId++,nb.build());
            Store.put(this,key,now+";"+risk.tier+";"+risk.leader);
            Store.put(this,"last_alert","预测压力提醒 · "+m.home+" vs "+m.away+" · "+m.minute+"' · "+risk.headline);
            Store.put(this,"last_alert_at",String.valueOf(now));
        } catch(SecurityException ignored) { Store.put(this,"service_error","通知权限被拒绝，请到手机设置允许GoalRadar通知"); }
    }
    private void notifyConfirmedGoal(MatchSample before, MatchSample now) {
        if (!GoalChangeDetector.newlyConfirmed(before,now)) return;
        int homeDiff=now.homeGoals-before.homeGoals, awayDiff=now.awayGoals-before.awayGoals;
        String scorer=homeDiff>0?now.home:now.away;
        String detail="已确认进球（不是提前预警） · "+now.minute+"' · "+now.home+" "+now.homeGoals+"-"+now.awayGoals+" "+now.away;
        Store.put(this,"last_goal_alert",detail);
        if (!notificationsAllowed(this)) {Store.put(this,"service_error","已检测到进球，但通知权限未开启");return;}
        Notification note=new Notification.Builder(this,CHANNEL)
             .setSmallIcon(android.R.drawable.ic_dialog_info)
             .setPriority(Notification.PRIORITY_HIGH)
             .setCategory(Notification.CATEGORY_EVENT)
             .setContentTitle("⚽ 进球确认 · "+scorer)
             .setContentText(detail).setStyle(new Notification.BigTextStyle().bigText(detail))
             .setContentIntent(openAppIntent()).setAutoCancel(true).build();
        try {
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(nextNotificationId++,note);
            Store.put(this,"last_alert",detail); Store.put(this,"last_alert_at",String.valueOf(System.currentTimeMillis()));
        } catch (SecurityException e) { Store.put(this,"service_error","已检测进球，但通知被系统拒绝"); }
    }
    static boolean notificationsAllowed(Context c) {
        NotificationManager nm=(NotificationManager)c.getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel alertChannel=nm.getNotificationChannel(CHANNEL);
        return nm.areNotificationsEnabled() && (alertChannel==null || alertChannel.getImportance()!=NotificationManager.IMPORTANCE_NONE)
                && (Build.VERSION.SDK_INT<33 ||
                c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);
    }
    static void testNotification(Context c) {
        ensureChannels(c);
        if(!notificationsAllowed(c))throw new IllegalStateException("通知权限未开启，请到系统设置允许通知");
        Notification n=new Notification.Builder(c,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(Notification.PRIORITY_HIGH)
            .setContentTitle("⚽ GoalRadar 通知测试成功")
            .setContentText("这只是通知链路测试，不代表比赛存在进球信号")
            .setAutoCancel(true).build();
        ((NotificationManager)c.getSystemService(NOTIFICATION_SERVICE)).notify(92,n);
        Store.put(c,"last_alert","测试通知已发送（不是进球信号）");
        Store.put(c,"last_alert_at",String.valueOf(System.currentTimeMillis()));
    }
    private PendingIntent openAppIntent() {
        return PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification monitorNotification(String detail) {
        return new Notification.Builder(this,RUN_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .setContentTitle("GoalRadar AI · 实时观察运行中")
            .setContentText(detail).setOngoing(true).setContentIntent(openAppIntent()).build();
    }
    private static void ensureChannels(Context context) {
        NotificationManager nm=(NotificationManager)context.getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel alerts=new NotificationChannel(CHANNEL,"进球压力预警",NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("比赛实时压力达到高等级时提醒"); nm.createNotificationChannel(alerts);
        NotificationChannel monitor=new NotificationChannel(RUN_CHANNEL,"持续观察状态",NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(monitor);
    }
    private String simplify(Exception e) {
        String msg=e.getMessage(); return e.getClass().getSimpleName()+": "+(msg==null?"未知错误":msg);
    }
    private void emit() {
        Intent signal=new Intent(CHANGED);signal.setPackage(getPackageName());sendBroadcast(signal);
    }
    @Override public void onDestroy() {
        if(task!=null)task.cancel(true);
        executor.shutdownNow();aiExecutor.shutdownNow();Store.running(this,false);emit();super.onDestroy();
    }
    // Android 15 limits dataSync foreground services to six hours per 24h in the background.
    @Override public void onTimeout(int startId,int fgsType) {
        Store.put(this,"service_error","Android系统已达到后台持续监测时长上限，请打开App重新启动");
        if(task!=null)task.cancel(true);
        Store.running(this,false);emit();stopSelf(startId);
    }
    @Override public IBinder onBind(Intent intent) {return null;}
}
