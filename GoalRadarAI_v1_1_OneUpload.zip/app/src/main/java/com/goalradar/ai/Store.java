package com.goalradar.ai;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

final class Store {
    private static SharedPreferences p(Context c) { return c.getSharedPreferences("goal_radar_state",Context.MODE_PRIVATE); }
    static synchronized List<String> ids(Context c) {
        List<String> out=new ArrayList<>();
        JSONArray arr=new JSONArray(); try { arr=new JSONArray(p(c).getString("ids","[]")); } catch(Exception ignored) {}
        for(int i=0;i<arr.length();i++) { String v=arr.optString(i); if(v.matches("\\d{5,12}")) out.add(v); }
        return out;
    }
    static synchronized boolean add(Context c, String id, String description) {
        if(id==null || !id.matches("\\d{5,12}")) return false;
        List<String> list=ids(c);
        if (list.contains(id) || list.size()>=20) return false;
        list.add(id); saveIds(c,list);
        p(c).edit().putString("description_"+id,description).apply(); return true;
    }
    static synchronized void remove(Context c,String id) {
        List<String> list=ids(c);list.remove(id);saveIds(c,list);
        p(c).edit().remove("hist_"+id).remove("latest_"+id).remove("risk_"+id)
                .remove("ai_"+id).remove("error_"+id).remove("alert_"+id).apply();
    }
    private static void saveIds(Context c,List<String> list) {
        p(c).edit().putString("ids",new JSONArray(list).toString()).apply();
    }
    static String get(Context c,String name) { return p(c).getString(name,""); }
    static void put(Context c,String name,String text) { p(c).edit().putString(name,text).apply(); }
    static boolean running(Context c) { return p(c).getBoolean("running",false); }
    static void running(Context c,boolean v) { p(c).edit().putBoolean("running",v).apply(); }
    static int interval(Context c) { return p(c).getInt("interval",60); }
    static void interval(Context c,int v) { p(c).edit().putInt("interval",Math.max(60,Math.min(600,v))).apply(); }
    static List<MatchSample> history(Context c,String id) {
        List<MatchSample> all=new ArrayList<>();
        try { JSONArray a=new JSONArray(get(c,"hist_"+id));
            for(int i=0;i<a.length();i++) all.add(MatchSample.from(a.optJSONObject(i)));
        } catch(Exception ignored) { }
        return all;
    }
    static void append(Context c,MatchSample m) {
        List<MatchSample> list=history(c,m.fixtureId);
        long cutoff=m.capturedAt-31*60*1000L;
        JSONArray a=new JSONArray();
        for(MatchSample old:list) if(old.capturedAt>=cutoff && old.capturedAt<m.capturedAt) a.put(old.json());
        a.put(m.json());
        put(c,"hist_"+m.fixtureId,a.toString());
        put(c,"latest_"+m.fixtureId,m.json().toString());
    }
    static JSONObject latest(Context c,String key) {
        try { return new JSONObject(get(c,key)); } catch(Exception e) { return new JSONObject(); }
    }
    static int alertLevel(Context c) { return p(c).getInt("alert_level",1); }
    static void alertLevel(Context c,int level) {p(c).edit().putInt("alert_level",Math.max(1,Math.min(2,level))).apply();}
    static long longValue(Context c,String key) {
        try{return Long.parseLong(get(c,key));}catch(Exception e){return 0;}
    }
}
