package com.goalradar.ai;
import java.util.*;
public class RiskEngineSmoke {
    static MatchSample sample(int minute,long seconds,int shots,int sot,int inside,Double xg){
        MatchSample m=new MatchSample();m.minute=minute;m.capturedAt=seconds*1000L;
        m.h.shots=shots;m.h.onTarget=sot;m.h.insideBox=inside;m.h.blocked=0;m.h.corners=0;m.h.xg=xg;
        m.a.shots=0;m.a.onTarget=0;m.a.insideBox=0;m.a.blocked=0;m.a.corners=0;m.a.xg=xg==null?null:0.0;
        return m;
    }
    static void require(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args) {
        MatchSample start=sample(16,1000,0,0,0,0.0);
        MatchSample live=sample(21,1300,2,1,1,.20);
        RiskEngine.Result r=RiskEngine.assess(List.of(start),live);
        require(r.tier>=RiskEngine.HIGH,"high-pressure change should alert: "+r.headline+" score="+r.score);
        MatchSample unknown=sample(21,1300,2,1,1,null);start.h.xg=null;start.a.xg=null;
        r=RiskEngine.assess(List.of(start),unknown);
        require(r.tier>=RiskEngine.MEDIUM,"missing xG should not disable pressure alerts");
        require(RiskEngine.assess(List.of(),live).tier==0,"cannot alert without baseline");
        require(RiskEngine.assess(List.of(start),sample(21,1300,0,0,0,null)).tier==0,"quiet phase must not alert");
        MatchSample after=sample(22,1360,2,1,1,null);after.homeGoals=1;
        require(GoalChangeDetector.newlyConfirmed(unknown,after),"new score should confirm goal");
        require(!GoalChangeDetector.newlyConfirmed(after,after),"identical snapshots not new goal");
        require(!GoalChangeDetector.newlyConfirmed(null,after),"no previous snapshot not a goal alert");
        System.out.println("PASS: scoring, fallback without xG, empty baseline, low pressure, score confirmation and dedup");
    }
}
