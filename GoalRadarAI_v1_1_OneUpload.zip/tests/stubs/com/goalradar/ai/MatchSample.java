package com.goalradar.ai;
final class MatchSample {
    String fixtureId="123456",home="主队",away="客队",status="1H";
    int minute=0,homeGoals=0,awayGoals=0,lastGoalMinute=-99;
    long capturedAt=0;
    Stats h=new Stats(),a=new Stats();
    boolean playing(){return "1H".equals(status)||"2H".equals(status)||"ET".equals(status);}
}
