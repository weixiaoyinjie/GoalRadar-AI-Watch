package com.goalradar.ai;
final class Stats {
    int shots=-1,onTarget=-1,insideBox=-1,blocked=-1,corners=-1;
    Double xg=null;
    int knownCount(){ return (shots>=0?1:0)+(onTarget>=0?1:0)+(insideBox>=0?1:0)+(blocked>=0?1:0)+(corners>=0?1:0)+(xg!=null?1:0); }
}
