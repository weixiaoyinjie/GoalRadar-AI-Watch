package org.json;
public class JSONObject {
    public JSONObject put(String name,Object value) { return this; }
}
