# GoalRadar AI v1.0 — 纯进球压力预警（Android）

**功能**：导入用户示例的图片模板 → 本地 OCR 识别 `Fixture ID` / 主客队 / 图片上的开赛时间 → 自动添加赛事 → API-Football v3 批量获取最新比分、事件、射门、部分联赛 xG → 利用时间快照评估近 5～10 分钟比赛变化 → 手机高压预警，OpenAI Responses API 可选解释。

**不是**一款比分预测/下注/自动跟单软件。分数不是进球概率，信号没有校准为概率。

## 1. 使用方法

1. 创建独立 GitHub 仓库，例如 `GoalRadar-AI-Watch`（不影响已有 APK）。
2. 仓库根目录上传 `GoalRadarAI_v1_OneUpload.zip`，再在 `.github/workflows/build-apk.yml` 创建同包中的 workflow（也提供单独文件）。
3. 推送到 `main`，打开 **Actions → Build GoalRadar AI APK → Run workflow**。
4. 构建完成后在 **Artifacts** 下载 `GoalRadarAI-v1-debug`，解压得到 `GoalRadarAI-v1-debug.apk`。
5. Android 安装 APK，填写 **API-Football Key**；可选填写自己的 **OpenAI API Key**。
6. 从图库选择别的应用生成的图片；或从分享菜单将图片分享到 GoalRadar AI。
7. 校验 OCR 得到的 Fixture ID，确认添加。点击「启动自动预警」。

注意：`2026-10-21 19:00` 为**截图所写时间，时区未知**，不能等同于球场当地时间。API 返回的赛程信息为准。

## 2. API 接口

- `GET https://v3.football.api-sports.io/fixtures?ids=1643187-...`，header `x-apisports-key`。
- `POST https://api.openai.com/v1/responses`，header `Authorization: Bearer <key>`。
- 默认 AI 模型 `gpt-4.1-mini`，可以改为账户可用且支持 Responses API 的模型。
- 完整 Fixture ID 必须属于**同一足球 API 数据提供商**；其他平台的 fixture ID 不保证通用。
- 部分赛事的 API 缺少 `Expected Goals`。缺失数据只显示“未提供”，绝不用其他指标冒充 xG。
- 危险进攻、进攻区域、逐次射门 xG 不在此版本默认可用字段内；未造假。

## 3. 信号和轮询

- 默认轮询：90 秒，批量查至多 20 场，最大 20 个 ID 拼接在单个请求里；可设 60～600 秒。
- 比分、时间、射门、射正、禁区内射门、封堵、角球及真实 xG 建立每场独立历史快照。使用本机快照采集的时间窗，不把累计统计误当成最近 5 分钟数据。
- 启动后的前 4～7 分钟仅观察；第 10 分钟左右才可初步比较相邻时间窗的趋势。
- 上半场 1～14 分钟不发声，半场休息、比赛结束不发声；进球后2分钟暂停触发。高等级通知冷却 7 分钟。
- AI 只解释，不参与底层触发。达到高等级时，每场最多约 10 分钟自动解释一次（有 Key 情况下）；也可手动点击「AI 分析」。
- API 实时统计更新受联赛、套餐、运营商、网络影响。比分已变化但射门统计滞后时，信号可能失真。风险指数未经过历史样本校准，不是概率。

## 4. 安全与设备限制

- 两个 API Key 在设备上使用 Android Keystore AES-GCM 加密保存，**不写入源码或 GitHub**。
- 该版本由安卓手机直接访问两家 API，适合个人私有使用；**正式公开发行时应改由自己控制的后端代理，避免客户端密钥暴露或被滥用**。
- 持续监听采用用户主动启动的 Android 前台服务，需要网络和保持通知。受 Android 省电策略、后台服务/Android 15 前台运行时长限制等影响，不能承诺 24 小时不中断。
- 若 API 未返回某场比赛、OCR 识别错 ID、KEY 无效或额度不足，显示错误并停止对该赛事做虚假实时判断。
- APK Debug 使用由 GitHub Actions 构建的测试签名，安装前请检查包名与来源。

## 5. 构建配置

- Java 17, AGP 8.7.3, Gradle 8.10.2, Android compileSdk 35, minSdk 26。
- ML Kit bundled Latin OCR：`com.google.mlkit:text-recognition:16.0.1`。
- workflow 包含解包、JDK/SDK配置、`gradle assembleDebug` 及 APK artifact 上传。
- 本文件包由 AI 编写，**当前环境不包含 Android SDK/Gradle，尚未在本地验证 APK 能成功编译**。请以 GitHub Actions 的实际结果为准。
