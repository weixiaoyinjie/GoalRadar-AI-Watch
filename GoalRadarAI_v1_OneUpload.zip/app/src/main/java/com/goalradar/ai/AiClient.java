package com.goalradar.ai;

import org.json.JSONArray;
import org.json.JSONObject;

/** Optional short explanation. Alert detection never depends on this network call. */
final class AiClient {
    static String explain(String key, String model, MatchSample match, RiskEngine.Result result) throws Exception {
        JSONObject data = new JSONObject();
        data.put("fixtureId",match.fixtureId);data.put("minute",match.minute);
        data.put("status",match.status);data.put("home",match.home);data.put("away",match.away);
        data.put("homeScore",match.homeGoals);data.put("awayScore",match.awayGoals);
        data.put("homeTotals",match.h.json());data.put("awayTotals",match.a.json());
        data.put("pressure",result.json());
        JSONObject payload = new JSONObject();
        payload.put("model",model);
        payload.put("store",false);
        payload.put("max_output_tokens",320);
        payload.put("instructions", "你是足球实时事件审查助手。仅根据提供的数据解释最近5-10分钟的进球压力变化，须区分累计数据和区间增量。"
                + "绝不能虚构xG、危险进攻、概率、盘口、阵容或视频画面；未知明确写未知。"
                + "只输出简短中文：1.当前状态 2.数据证据 3.趋势 4.最大风险 5.观察结论。"
                + "不要做投注推荐，不要把压力分数说成进球概率，不要宣称必进球。");
        payload.put("input", "审核以下实时快照和规则计算结果。规则压力值只代表量表，非概率。数据："+data);
        JSONObject response = Http.request("https://api.openai.com/v1/responses","POST","Authorization","Bearer "+key,payload);
        String resultText=response.optString("output_text","");
        if (!resultText.isEmpty()) return resultText;
        JSONArray out=response.optJSONArray("output");
        if(out!=null) for(int i=0;i<out.length();i++) {
            JSONObject msg=out.optJSONObject(i); if(msg==null) continue;
            JSONArray blocks=msg.optJSONArray("content"); if(blocks==null)continue;
            for(int j=0;j<blocks.length();j++) {
                JSONObject b=blocks.optJSONObject(j);
                if(b!=null && "output_text".equals(b.optString("type"))) return b.optString("text", "AI未返回文字");
            }
        }
        JSONObject error=response.optJSONObject("error");
        throw new IllegalStateException(error == null ? "AI 未返回正文" : error.optString("message","AI调用失败"));
    }
}
