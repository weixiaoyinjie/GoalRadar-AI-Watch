package com.goalradar.ai;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extracts the user's fixed screenshot template; Fixture ID is authoritative. */
public final class FixtureOcrParser {
    public final String fixtureId;
    public final String home;
    public final String away;
    public final String pictureDateTime;
    public final String rawText;

    private FixtureOcrParser(String id, String h, String a, String dt, String raw) {
        fixtureId = id; home = h; away = a; pictureDateTime = dt; rawText = raw;
    }

    public static FixtureOcrParser parse(String text) {
        String clean = text == null ? "" : text.replace('\u00a0', ' ');
        Matcher id = Pattern.compile("(?i)Fixture\\s*[I1l|][D0Oo]\\s*[:：\\-]?\\s*(\\d{5,12})").matcher(clean);
        if (!id.find()) {
            // OCR can split the ID label across lines. Never guess an ID from the date.
            throw new IllegalArgumentException("未识别到 Fixture ID。请使用手动输入 ID。");
        }
        String fixture = id.group(1);
        String home = "", away = "", date = "";
        Matcher vs = Pattern.compile("(?im)^\\s*(.{2,90}?)\\s+(?:vs\\.?|versus)\\s+(.{2,90}?)\\s*$").matcher(clean);
        if (vs.find()) { home = vs.group(1).trim(); away = vs.group(2).trim(); }
        Matcher dt = Pattern.compile("(20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}\\s+\\d{1,2}:\\d{2})").matcher(clean);
        if (dt.find()) date = dt.group(1);
        return new FixtureOcrParser(fixture, home, away, date, clean);
    }
}
