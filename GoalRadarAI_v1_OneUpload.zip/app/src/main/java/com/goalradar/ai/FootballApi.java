package com.goalradar.ai;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** API-FOOTBALL v3 /fixtures?ids=... includes embedded match statistics where supported. */
final class FootballApi {
    static List<MatchSample> fetch(List<String> ids, String apiKey) throws Exception {
        if (ids.isEmpty()) return Collections.emptyList();
        String joined = String.join("-", ids);
        JSONObject response = Http.request("https://v3.football.api-sports.io/fixtures?ids=" + joined,
                "GET", "x-apisports-key", apiKey, null);
        JSONObject errors = response.optJSONObject("errors");
        if (errors != null && errors.length() > 0) throw new IllegalStateException("足球 API 错误: " + errors.toString());
        JSONArray list = response.optJSONArray("response");
        List<MatchSample> out = new ArrayList<>();
        if (list == null) return out;
        for (int i = 0; i < list.length(); i++) {
            JSONObject row = list.optJSONObject(i); if (row == null) continue;
            out.add(parse(row));
        }
        return out;
    }

    static MatchSample parse(JSONObject row) {
        MatchSample s = new MatchSample();
        JSONObject fixture = row.optJSONObject("fixture");
        JSONObject teams = row.optJSONObject("teams");
        JSONObject score = row.optJSONObject("goals");
        if (fixture == null || teams == null) return s;
        s.fixtureId = String.valueOf(fixture.optLong("id"));
        JSONObject time = fixture.optJSONObject("status");
        s.status = time == null ? "NS" : time.optString("short", "NS");
        s.minute = time == null ? 0 : time.optInt("elapsed", 0);
        s.kickoff = fixture.optString("date", "");
        JSONObject h = teams.optJSONObject("home"), a = teams.optJSONObject("away");
        int homeTeamId = h == null ? -1 : h.optInt("id", -1);
        int awayTeamId = a == null ? -1 : a.optInt("id", -1);
        s.home = h == null ? "主队" : h.optString("name", "主队");
        s.away = a == null ? "客队" : a.optString("name", "客队");
        if (score != null) {
            s.homeGoals = score.optInt("home",0); s.awayGoals = score.optInt("away",0);
        }
        JSONObject league = row.optJSONObject("league");
        if (league != null) s.league = league.optString("country") + " · " + league.optString("name");

        JSONArray allStats = row.optJSONArray("statistics");
        if (allStats != null) {
            for (int j = 0; j < allStats.length(); j++) {
                JSONObject entry = allStats.optJSONObject(j);
                if (entry == null) continue;
                JSONObject tm = entry.optJSONObject("team");
                int teamId = tm == null ? -1 : tm.optInt("id",-1);
                if (teamId == homeTeamId && teamId >= 0) s.h = parseStats(entry.optJSONArray("statistics"));
                if (teamId == awayTeamId && teamId >= 0) s.a = parseStats(entry.optJSONArray("statistics"));
            }
        }
        JSONArray events = row.optJSONArray("events");
        if (events != null) for (int j = 0; j < events.length(); j++) {
            JSONObject e = events.optJSONObject(j); if (e == null) continue;
            String type = e.optString("type");
            if ("Goal".equalsIgnoreCase(type)) {
                JSONObject t = e.optJSONObject("time");
                if (t != null) s.lastGoalMinute = Math.max(s.lastGoalMinute, t.optInt("elapsed", -99));
            }
        }
        return s;
    }

    private static Stats parseStats(JSONArray list) {
        Stats s = new Stats();
        if (list == null) return s;
        for (int i = 0; i < list.length(); i++) {
            JSONObject st = list.optJSONObject(i); if (st == null) continue;
            Object raw = st.opt("value");
            if (raw == null || JSONObject.NULL.equals(raw)) continue;
            String text = String.valueOf(raw).replace("%", "").trim();
            double parsed;
            try { parsed = Double.parseDouble(text); } catch(Exception ex) { continue; }
            if (parsed < 0 || !Double.isFinite(parsed)) continue;
            String key = st.optString("type", "").toLowerCase(Locale.ROOT)
                    .replaceAll("[^a-z0-9]", "");
            int n = (int)Math.round(parsed);
            switch (key) {
                case "totalshots": s.shots = n; break;
                case "shotsongoal": case "shotsontarget": s.onTarget = n; break;
                case "shotsinsidebox": case "shotsinside": s.insideBox = n; break;
                case "blockedshots": s.blocked = n; break;
                case "cornerkicks": case "corners": s.corners = n; break;
                case "expectedgoals": case "xg": s.xg = parsed; break;
                default: break;
            }
        }
        return s;
    }
}
