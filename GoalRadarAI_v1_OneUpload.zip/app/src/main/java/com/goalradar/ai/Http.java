package com.goalradar.ai;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

final class Http {
    static JSONObject request(String endpoint, String method, String authHeader, String authValue, JSONObject body) throws Exception {
        URL url = new URL(endpoint);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod(method); c.setConnectTimeout(13000); c.setReadTimeout(20000);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty(authHeader, authValue);
        try {
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) { out.write(payload); }
            }
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            StringBuilder buf = new StringBuilder();
            if (in != null) {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line; while ((line = r.readLine()) != null) buf.append(line);
                }
            }
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + buf.substring(0, Math.min(200,buf.length())));
            return new JSONObject(buf.toString());
        } finally { c.disconnect(); }
    }
}
