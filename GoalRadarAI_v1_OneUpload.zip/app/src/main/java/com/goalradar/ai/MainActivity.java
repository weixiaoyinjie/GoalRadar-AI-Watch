package com.goalradar.ai;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int PICK=100;
    private static final int BG=0xff07131c, PANEL=0xff132734, ACCENT=0xff56e1d0;
    private static final int WHITE=0xffecf6f7, MUTED=0xff9bb6be;
    private EditText footballInput, aiInput, modelInput, idInput, intervalInput;
    private LinearLayout cards, settingsPanel;
    private TextView status, count;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable redraw=new Runnable() { @Override public void run() {refreshCards();handler.postDelayed(this,12000);} };
    private final BroadcastReceiver receiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {refreshCards();}
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        buildUi();
        if (getIntent()!=null && Intent.ACTION_SEND.equals(getIntent().getAction())) {
            Uri uri;
            if(Build.VERSION.SDK_INT>=33) uri=getIntent().getParcelableExtra(Intent.EXTRA_STREAM,Uri.class);
            else uri=getIntent().getParcelableExtra(Intent.EXTRA_STREAM);
            if(uri!=null) recognize(uri);
        }
    }
    @Override public void onStart() {
        super.onStart();
        IntentFilter filter=new IntentFilter(RadarService.CHANGED);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,filter,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver,filter);
        handler.post(redraw);
    }
    @Override public void onStop() {
        handler.removeCallbacks(redraw);
        try{unregisterReceiver(receiver);}catch(Exception ignored){}
        super.onStop();
    }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(22),dp(16),dp(28));
        scroll.addView(root);setContentView(scroll);
        TextView brand=text("GOALRADAR  AI",28,ACCENT,true);root.addView(brand);
        root.addView(text("实时进球压力预警 · 图片导入 · AI交叉解释",13,MUTED,false));
        gap(root,18);
        status=text("监测已停止",14,WHITE,true);root.addView(status);
        gap(root,10);

        LinearLayout imports=panel();root.addView(imports);
        imports.addView(text("① 导入比赛截图",18,WHITE,true));
        imports.addView(text("支持你提供的固定模板：开赛时间 / 主客队 / Fixture ID",12,MUTED,false));
        gap(imports,10);
        Button scan=button("从相册识别图片",ACCENT,Color.BLACK);imports.addView(scan);
        scan.setOnClickListener(v->pickImage());
        idInput=edit("也可直接输入 Fixture ID（例：1643187）",InputType.TYPE_CLASS_NUMBER);
        imports.addView(idInput);
        Button add=button("手动添加比赛",PANEL,WHITE);imports.addView(add);
        add.setOnClickListener(v->addManual());
        gap(root,12);

        LinearLayout control=panel();root.addView(control);
        control.addView(text("② 监测控制",18,WHITE,true));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button start=button("启动自动预警",0xff28c6ae,Color.BLACK);
        Button stop=button("停止监测",0xff345265,WHITE);
        actions.addView(start,new LinearLayout.LayoutParams(0,dp(50),1));
        LinearLayout.LayoutParams stopLp=new LinearLayout.LayoutParams(0,dp(50),1);stopLp.leftMargin=dp(8);
        actions.addView(stop,stopLp);control.addView(actions);
        start.setOnClickListener(v->{saveSettings(false);checkNotifyPermission();startMonitor(RadarService.START);});
        stop.setOnClickListener(v->startService(new Intent(this,RadarService.class).setAction(RadarService.STOP)));
        Button once=button("立即拉取最新数据",0xff274352,WHITE);control.addView(once);
        once.setOnClickListener(v->{saveSettings(false);startMonitor(RadarService.ONCE);});
        control.addView(text("默认每90秒批量查询一次；高等级才自动调用AI。持续预警需要保留监测通知。",12,MUTED,false));
        gap(root,12);

        LinearLayout settings=panel();root.addView(settings);
        Button toggle=button("③ API 设置（点击展开／收起）",0xff28404d,WHITE);settings.addView(toggle);
        settingsPanel=new LinearLayout(this);settingsPanel.setOrientation(LinearLayout.VERTICAL);
        settingsPanel.setVisibility(View.GONE);settings.addView(settingsPanel);
        settingsPanel.addView(text("API-Football Key（必填）",13,MUTED,false));
        footballInput=edit("填入足球 API Key；留空表示保留旧 Key",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        settingsPanel.addView(footballInput);
        settingsPanel.addView(text("OpenAI API Key（选填）",13,MUTED,false));
        aiInput=edit("填入 ChatGPT API Key；留空保留旧 Key",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        settingsPanel.addView(aiInput);
        settingsPanel.addView(text("模型名称",13,MUTED,false));
        modelInput=edit("gpt-4.1-mini",InputType.TYPE_CLASS_TEXT);
        String model=Store.get(this,"model");modelInput.setText(model.isEmpty()?"gpt-4.1-mini":model);
        settingsPanel.addView(modelInput);
        settingsPanel.addView(text("轮询秒数：60～600",13,MUTED,false));
        intervalInput=edit("90",InputType.TYPE_CLASS_NUMBER);intervalInput.setText(String.valueOf(Store.interval(this)));
        settingsPanel.addView(intervalInput);
        Button save=button("保存设置",ACCENT,Color.BLACK);settingsPanel.addView(save);
        save.setOnClickListener(v->saveSettings(true));
        Button clear=button("清除本机已存的两个 API Key",0xff394752,WHITE);settingsPanel.addView(clear);
        clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("确定清除 API Key？")
                .setPositiveButton("清除",(d,w)->{try{SecurePrefs.put(this,"football","");SecurePrefs.put(this,"openai","");toast("已清除");}
                    catch(Exception ex){toast("清除失败："+ex.getMessage());}})
                .setNegativeButton("取消",null).show());
        toggle.setOnClickListener(v->settingsPanel.setVisibility(settingsPanel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
        gap(root,12);

        LinearLayout watch=panel();root.addView(watch);
        count=text("④ 观察列表（0 / 20）",18,WHITE,true);watch.addView(count);
        watch.addView(text("预警压力指数 ≠ 未来进球概率。数据不足显示观察。",12,MUTED,false));
        cards=new LinearLayout(this);cards.setOrientation(LinearLayout.VERTICAL);watch.addView(cards);
        gap(root,12);
        root.addView(text("提示：仅输出真实API数据。xG缺失时不会用射门数伪造xG。若频繁查询20场，请检查API套餐额度。",12,MUTED,false));
        refreshCards();
    }

    private void pickImage() {
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("image/*");
        startActivityForResult(intent,PICK);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==PICK && result==RESULT_OK && data!=null && data.getData()!=null) recognize(data.getData());
    }
    private void recognize(Uri uri) {
        toast("正在读取截图文字…");
        try {
            InputImage img=InputImage.fromFilePath(this,uri);
            var rec=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            rec.process(img).addOnSuccessListener(found->{
                rec.close();
                try {
                    FixtureOcrParser fixture=FixtureOcrParser.parse(found.getText());
                    String labels=fixture.home+" vs "+fixture.away;
                    String detail=fixture.pictureDateTime+" | "+labels;
                    new AlertDialog.Builder(this).setTitle("图片识别成功")
                            .setMessage("Fixture ID: "+fixture.fixtureId+"\n"+detail+"\n\n最终比赛信息将由足球API核实。")
                            .setPositiveButton("添加观察",(d,w)->{
                                boolean ok=Store.add(this,fixture.fixtureId,detail);
                                toast(ok?"已加入观察："+fixture.fixtureId:"该比赛已存在或超过20场");refreshCards();
                            })
                            .setNegativeButton("取消",null).show();
                } catch(Exception ex) {
                    new AlertDialog.Builder(this).setTitle("未自动找到 Fixture ID")
                            .setMessage("请手动输入 ID。原始 OCR 文字：\n"+found.getText())
                            .setPositiveButton("确定",null).show();
                }
            }).addOnFailureListener(ex->{rec.close();toast("图片识别失败："+ex.getMessage());});
        } catch(Exception ex){toast("读取图片失败："+ex.getMessage());}
    }
    private void addManual() {
        String id=idInput.getText().toString().trim();
        if(!id.matches("\\d{5,12}")) {toast("请输入完整的 Fixture ID");return;}
        boolean ok=Store.add(this,id,"用户手动添加");
        if(ok){idInput.setText("");toast("已加入观察："+id);}else toast("重复比赛或已达到20场");
        refreshCards();
    }
    private void checkNotifyPermission() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},333);
        }
    }
    private void startMonitor(String action) {
        if(Store.ids(this).isEmpty()){toast("先导入一场比赛");return;}
        if(SecurePrefs.get(this,"football").isEmpty()){toast("先展开API设置，保存足球 API Key");return;}
        try{startForegroundService(new Intent(this,RadarService.class).setAction(action));toast("已发送监测命令");}
        catch(Exception e){toast("无法启动监测："+e.getMessage());}
    }
    private void saveSettings(boolean show) {
        try {
            String fk=footballInput.getText().toString().trim();
            String ak=aiInput.getText().toString().trim();
            if(!fk.isEmpty())SecurePrefs.put(this,"football",fk);
            if(!ak.isEmpty())SecurePrefs.put(this,"openai",ak);
            Store.put(this,"model",modelInput.getText().toString().trim().isEmpty()?"gpt-4.1-mini":modelInput.getText().toString().trim());
            int seconds=90;try{seconds=Integer.parseInt(intervalInput.getText().toString());}catch(Exception ignored){}
            Store.interval(this,seconds);
            if(show)toast("设置已保存。更改轮询频率后请停止并重新启动监测。");
            footballInput.setText("");aiInput.setText("");
        } catch(Exception e) {toast("设置保存失败："+e.getMessage());}
    }
    private void refreshCards() {
        if(cards==null)return;
        List<String> ids=Store.ids(this);
        count.setText("④ 观察列表（"+ids.size()+" / 20）");
        String err=Store.get(this,"service_error");
        long beat=Store.longValue(this,"heartbeat");
        boolean running=Store.running(this);
        boolean stale=running && beat>0 && System.currentTimeMillis()-beat>Math.max(180000,Store.interval(this)*3000L);
        status.setText((stale?"🟠 监测数据长时间未更新（可能被系统暂停）":running?"🟢 观察服务已启动":"⚪ 观察服务已停止")
                +(err.isEmpty()?"":"\n接口状态："+err));
        cards.removeAllViews();
        if(ids.isEmpty()){cards.addView(text("暂无比赛。先从其他软件导出截图，再导入这里。",14,MUTED,false));return;}
        for(String id:ids) drawMatch(id);
    }
    private void drawMatch(String id) {
        JSONObject raw=Store.latest(this,"latest_"+id), risk=Store.latest(this,"risk_"+id);
        boolean hasLive=raw.has("fixtureId");
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(13),dp(14),dp(13),dp(14));
        card.setBackground(makeBox(0xff1b3443,12));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);cards.addView(card,p);
        MatchSample game=hasLive?MatchSample.from(raw):null;
        String head=hasLive?game.home+"  "+game.homeGoals+" - "+game.awayGoals+"  "+game.away:Store.get(this,"description_"+id);
        card.addView(text(head.isEmpty()?"Fixture "+id:head,16,WHITE,true));
        card.addView(text("Fixture ID "+id+(hasLive?" · "+game.minute+"' · "+game.status+" · "+game.league:" · 等待足球API核验"),12,MUTED,false));
        if(hasLive) {
            long age=System.currentTimeMillis()-game.capturedAt;
            if(age>Math.max(180000L,Store.interval(this)*3000L))
                card.addView(text("⚠ 这是历史快照，距上次采集约"+(age/60000)+"分钟，不代表当前实时压力",12,0xffffb47e,true));
            if (!game.kickoff.isEmpty()) card.addView(text("API开赛时间："+game.kickoff,11,MUTED,false));
            card.addView(text("射门："+stat(game.h.shots)+" / "+stat(game.a.shots)
                    +"   射正："+stat(game.h.onTarget)+" / "+stat(game.a.onTarget)
                    +"   禁区内："+stat(game.h.insideBox)+" / "+stat(game.a.insideBox),12,WHITE,false));
            card.addView(text("累计xG："+fmtXg(game.h.xg)+" / "+fmtXg(game.a.xg)+" （真实来源值）",12,MUTED,false));
        }
        int tier=risk.optInt("tier",0);
        int color=tier==3?0xffff6d6d:tier==2?0xffffbc69:tier==1?0xffdfd58a:ACCENT;
        String label=tier==3?"严重压力":tier==2?"高压预警":tier==1?"中等压力":"继续观察";
        card.addView(text(label+"  ·  压力指数 "+risk.optInt("score",0)+"/100（非进球概率）",14,color,true));
        String message=risk.optString("headline", "等待第一份实时数据");
        card.addView(text(message,12,WHITE,false));
        String evidence=risk.optString("evidence", "");
        if(!evidence.isEmpty())card.addView(text(evidence,12,MUTED,false));
        String limitation=risk.optString("limitation", "");
        if(!limitation.isEmpty())card.addView(text("限制："+limitation,12,0xffffc991,false));
        String error=Store.get(this,"error_"+id);
        if(!error.isEmpty())card.addView(text(error,12,0xffff8e8e,false));
        String ai=Store.get(this,"ai_"+id);
        if(!ai.isEmpty())card.addView(text("AI 最近分析：\n"+ai,12,WHITE,false));
        LinearLayout action=new LinearLayout(this);action.setOrientation(LinearLayout.HORIZONTAL);card.addView(action);
        Button analyze=button("AI 分析",0xff306070,WHITE);
        action.addView(analyze,new LinearLayout.LayoutParams(0,dp(46),1));
        analyze.setOnClickListener(v->manualAi(id));
        Button remove=button("移除",0xff354654,WHITE);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(46),1);rp.leftMargin=dp(8);
        action.addView(remove,rp);
        remove.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("从观察列表移除这场比赛？")
                .setPositiveButton("移除",(d,w)->{Store.remove(this,id);refreshCards();})
                .setNegativeButton("取消",null).show());
    }
    private void manualAi(String id) {
        String key=SecurePrefs.get(this,"openai");
        if(key.isEmpty()){toast("请先保存 OpenAI API Key");return;}
        JSONObject latest=Store.latest(this,"latest_"+id);
        if(latest.length()==0){toast("需要先拉取一份实时数据");return;}
        toast("正在请求AI分析…");
        new Thread(()->{
            try {
                MatchSample game=MatchSample.from(latest);
                RiskEngine.Result risk=RiskEngine.assess(Store.history(this,id),game);
                String model=Store.get(this,"model");
                String msg=AiClient.explain(key,model.isEmpty()?"gpt-4.1-mini":model,game,risk);
                Store.put(this,"ai_"+id,msg);
                runOnUiThread(()->{refreshCards();new AlertDialog.Builder(this).setTitle("AI 数据审核 · "+id)
                        .setMessage(msg).setPositiveButton("关闭",null).show();});
            } catch(Exception e){runOnUiThread(()->toast("AI分析失败："+e.getMessage()));}
        }).start();
    }
    private String stat(int n){return n<0?"缺失":String.valueOf(n);}
    private String fmtXg(Double n){return n==null?"未提供":String.format(Locale.US,"%.2f",n);}
    private LinearLayout panel() {
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(dp(14),dp(14),dp(14),dp(14));b.setBackground(makeBox(PANEL,14));return b;
    }
    private android.graphics.drawable.GradientDrawable makeBox(int col,int radius) {
        android.graphics.drawable.GradientDrawable gd=new android.graphics.drawable.GradientDrawable();
        gd.setColor(col);gd.setCornerRadius(dp(radius));return gd;
    }
    private TextView text(String value,int size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setPadding(0,dp(3),0,dp(4));return t;
    }
    private EditText edit(String hint,int mode) {
        EditText e=new EditText(this);e.setHint(hint);e.setTextColor(WHITE);e.setHintTextColor(MUTED);
        e.setTextSize(14);e.setInputType(mode);e.setSingleLine(true);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        e.setPadding(dp(4),dp(9),dp(4),dp(9));return e;
    }
    private Button button(String name,int color,int fg) {
        Button b=new Button(this);b.setText(name);b.setTextColor(fg);b.setTextSize(12);b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }
    private void gap(LinearLayout target,int height) {
        View v=new View(this);target.addView(v,new LinearLayout.LayoutParams(-1,dp(height)));
    }
    private int dp(int pixels) {return (int)(pixels*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
