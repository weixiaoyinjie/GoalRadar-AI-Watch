package com.goalradar.ai;

import org.json.JSONObject;

final class MatchSample {
    String fixtureId = "", home = "", away = "", status = "NS", league = "";
    String kickoff = "";
    int minute = 0, homeGoals = 0, awayGoals = 0, lastGoalMinute = -99;
    long capturedAt = System.currentTimeMillis();
    Stats h = new Stats(), a = new Stats();

    JSONObject json() {
        JSONObject j = new JSONObject();
        try {
            j.put("fixtureId",fixtureId); j.put("home",home); j.put("away",away);
            j.put("status",status); j.put("league",league); j.put("kickoff",kickoff);
            j.put("minute",minute); j.put("homeGoals",homeGoals); j.put("awayGoals",awayGoals);
            j.put("lastGoalMinute",lastGoalMinute); j.put("capturedAt",capturedAt);
            j.put("h",h.json()); j.put("a",a.json());
        } catch(Exception ignored) { }
        return j;
    }
    static MatchSample from(JSONObject j) {
        MatchSample s = new MatchSample();
        if (j == null) return s;
        s.fixtureId = j.optString("fixtureId"); s.home = j.optString("home");
        s.away = j.optString("away"); s.status = j.optString("status", "NS");
        s.league = j.optString("league"); s.kickoff = j.optString("kickoff");
        s.minute = j.optInt("minute"); s.homeGoals = j.optInt("homeGoals");
        s.awayGoals = j.optInt("awayGoals"); s.lastGoalMinute = j.optInt("lastGoalMinute", -99);
        s.capturedAt = j.optLong("capturedAt", 0); s.h = Stats.from(j.optJSONObject("h"));
        s.a = Stats.from(j.optJSONObject("a"));
        return s;
    }
    boolean playing() { return "1H".equals(status) || "2H".equals(status) || "ET".equals(status); }
}
