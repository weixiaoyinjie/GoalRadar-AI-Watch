package com.goalradar.ai;

import java.util.*;
import org.json.JSONObject;

/** Interpretable pressure score, not a calibrated probability of goal. */
final class RiskEngine {
    static final int OBSERVE=0, MEDIUM=1, HIGH=2, SEVERE=3;
    static final class Result {
        int tier = OBSERVE, score = 0;
        String leader = "", headline = "观察中", evidence = "", limitation = "", trend = "样本不足";
        double dxgHome = Double.NaN, dxgAway = Double.NaN;
        int shotHome = -1, shotAway = -1, sotHome = -1, sotAway = -1;
        JSONObject json() {
            JSONObject j = new JSONObject(); try {
                j.put("tier",tier); j.put("score",score); j.put("leader",leader);
                j.put("headline",headline); j.put("evidence",evidence);
                j.put("limitation",limitation); j.put("trend",trend);
                putFinite(j,"dxgHome",dxgHome); putFinite(j,"dxgAway",dxgAway);
                j.put("shotHome",shotHome); j.put("shotAway",shotAway);
                j.put("sotHome",sotHome); j.put("sotAway",sotAway);
            } catch (Exception ignored) {} return j;
        }
        static void putFinite(JSONObject j, String key, double val) throws Exception {
            if (Double.isFinite(val)) j.put(key,val);
        }
    }
    private static final class Delta {
        int sot, inside, shots, blocked, corners;
        Double xg;
        int usable = 0;
        Delta(Stats n, Stats old) {
            sot = delta(n.onTarget, old.onTarget);
            inside = delta(n.insideBox, old.insideBox);
            shots = delta(n.shots, old.shots);
            blocked = delta(n.blocked, old.blocked);
            corners = delta(n.corners, old.corners);
            if (n.xg != null && old.xg != null) {
                double d = n.xg - old.xg;
                if (d >= 0 && d <= 5) xg = d;
            }
            if (sot >= 0) usable++;
            if (inside >= 0) usable++;
            if (shots >= 0) usable++;
            if (blocked >= 0) usable++;
            if (corners >= 0) usable++;
            if (xg != null) usable++;
        }
        int delta(int n, int old) { return (n < 0 || old < 0 || n < old) ? -1 : n-old; }
        double clamp(int n) { return n < 0 ? 0 : n; }
        int pressure() {
            double points = clamp(sot)*22 + clamp(inside)*13 + clamp(shots)*4
                    + clamp(blocked)*5 + clamp(corners)*3;
            if (xg != null) points += xg*65;
            return (int)Math.min(100, Math.round(points));
        }
        boolean highEvidence() {
            return ((sot>=2 && inside>=2) || (xg!=null && xg>=0.20 && shots>=2 && inside>=1)
                || (sot>=3 && shots>=4));
        }
        boolean severeEvidence() {
            return xg!=null && xg>=0.35 && sot>=2 && inside>=2;
        }
        String evidence() {
            return "最近5分钟 射门 +"+fmt(shots)+" / 射正 +"+fmt(sot)
                    +" / 禁区内 +"+fmt(inside)+" / 角球 +"+fmt(corners)
                    +" / xG +"+(xg == null ? "无数据" : String.format(Locale.US,"%.2f",xg));
        }
        String fmt(int n) { return n < 0 ? "?" : String.valueOf(n); }
    }

    private static MatchSample near(List<MatchSample> history, long timestamp, long minAgeMs, long maxAgeMs) {
        MatchSample best = null; long bestDiff=Long.MAX_VALUE;
        for (MatchSample s : history) {
            long age = timestamp - s.capturedAt;
            if (age < minAgeMs || age > maxAgeMs) continue;
            long d = Math.abs(age - ((minAgeMs + maxAgeMs) / 2));
            if (d < bestDiff) { best=s; bestDiff=d; }
        }
        return best;
    }
    static Result assess(List<MatchSample> previous, MatchSample now) {
        Result r = new Result();
        r.leader = now.home;
        if (!now.playing()) { r.headline = "未处于比赛进行阶段（"+now.status+"）"; return r; }
        if ("1H".equals(now.status) && now.minute < 15) { r.headline="上半场前15分钟：先观察"; return r; }
        if (now.h.knownCount() < 2 || now.a.knownCount() < 2) {
            r.headline = "统计缺失：不触发预警";
            r.limitation = "该联赛的实时数据不足"; return r;
        }
        MatchSample five = near(previous, now.capturedAt, 4*60000L, 7*60000L);
        if (five == null || !five.playing() || !five.status.equals(now.status)) {
            r.headline="积累最近5分钟数据中"; return r;
        }
        Delta hd = new Delta(now.h, five.h), ad = new Delta(now.a, five.a);
        r.dxgHome = hd.xg == null ? Double.NaN : hd.xg;
        r.dxgAway = ad.xg == null ? Double.NaN : ad.xg;
        r.shotHome=hd.shots; r.shotAway=ad.shots;
        r.sotHome=hd.sot; r.sotAway=ad.sot;
        if (hd.usable < 3 || ad.usable < 3) {
            r.headline="关键指标不足：继续观察"; r.limitation="缺少多项射门数据"; return r;
        }
        int hp=hd.pressure(), ap=ad.pressure();
        boolean homeBetter=hp>=ap; Delta dominant=homeBetter?hd:ad;
        int opposing=homeBetter?ap:hp;
        r.leader=homeBetter?now.home:now.away;
        r.score = dominant.pressure();
        r.evidence = dominant.evidence();
        if (dominant.xg == null) r.limitation="xG缺失：只按可得射门数据降级判断；不能算进球概率";
        if (now.minute-now.lastGoalMinute<=2) {
            r.headline="刚刚发生进球：暂缓预警，等待阵型稳定"; return r;
        }
        if (r.score >= 75 && dominant.severeEvidence() && r.score-opposing>=25) r.tier = SEVERE;
        else if (r.score>=58 && dominant.highEvidence() && r.score-opposing>=18) r.tier=HIGH;
        else if (r.score>=32 && dominant.shots>=1 && r.score-opposing>=10) r.tier=MEDIUM;
        else r.tier=OBSERVE;
        if (dominant.xg == null && r.tier>HIGH) r.tier=HIGH;
        MatchSample ten = near(previous, now.capturedAt, 9*60000L, 12*60000L);
        if (ten != null && ten.playing() && ten.status.equals(now.status)) {
            Delta past = homeBetter?new Delta(five.h, ten.h):new Delta(five.a, ten.a);
            int pp=past.pressure();
            r.trend = r.score>pp+18 ? "增强" : (r.score<pp-18 ? "衰减" : "持平");
        } else r.trend="等待10分钟样本";
        r.headline = (r.tier==SEVERE?"严重压力":r.tier==HIGH?"高压预警":r.tier==MEDIUM?"中等压力":"暂未形成持续威胁")
                + " · " + r.leader;
        if (opposing >=58 && opposing >= r.score-12) {
            r.tier = Math.min(r.tier, MEDIUM);
            r.headline="双方都有攻势：方向不明确";
            r.limitation += " 双方压力接近，不判定单方主导。";
        }
        return r;
    }
}
