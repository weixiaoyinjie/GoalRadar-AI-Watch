package com.goalradar.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Keys encrypted at rest with Android Keystore. Never write keys into builds or logs. */
final class SecurePrefs {
    private static final String ALIAS="goal_radar_aes_gcm_key";
    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("secure_api_keys", Context.MODE_PRIVATE);
    }
    private static SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            kg.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
    }
    static void put(Context c,String name,String plain) throws Exception {
        if (plain==null || plain.isEmpty()) { prefs(c).edit().remove(name).apply(); return; }
        Cipher cip=Cipher.getInstance("AES/GCM/NoPadding");
        cip.init(Cipher.ENCRYPT_MODE,key());
        byte[] bytes=cip.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        String saved=Base64.encodeToString(cip.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(bytes,Base64.NO_WRAP);
        prefs(c).edit().putString(name,saved).apply();
    }
    static String get(Context c,String name) {
        String saved=prefs(c).getString(name,""); if(saved.isEmpty()) return "";
        try {
            String[] bits=saved.split(":",2); if(bits.length!=2)return "";
            Cipher cip=Cipher.getInstance("AES/GCM/NoPadding");
            cip.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(bits[0],Base64.NO_WRAP)));
            return new String(cip.doFinal(Base64.decode(bits[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
        } catch(Exception e) { return ""; }
    }
}
