package com.goalradar.ai;

import org.json.JSONObject;

final class Stats {
    int shots = -1, onTarget = -1, insideBox = -1, blocked = -1, corners = -1;
    Double xg = null;
    int knownCount() {
        int count = 0;
        if (shots >= 0) count++;
        if (onTarget >= 0) count++;
        if (insideBox >= 0) count++;
        if (blocked >= 0) count++;
        if (corners >= 0) count++;
        if (xg != null) count++;
        return count;
    }
    JSONObject json() {
        JSONObject j = new JSONObject();
        try {
            j.put("shots", shots); j.put("onTarget", onTarget); j.put("insideBox", insideBox);
            j.put("blocked", blocked); j.put("corners", corners);
            if (xg != null) j.put("xg", xg);
        } catch(Exception ignored) { }
        return j;
    }
    static Stats from(JSONObject j) {
        Stats s = new Stats();
        if (j == null) return s;
        s.shots = j.optInt("shots", -1); s.onTarget = j.optInt("onTarget", -1);
        s.insideBox = j.optInt("insideBox", -1); s.blocked = j.optInt("blocked", -1);
        s.corners = j.optInt("corners", -1);
        if (!j.isNull("xg") && j.has("xg")) s.xg = j.optDouble("xg");
        return s;
    }
}
